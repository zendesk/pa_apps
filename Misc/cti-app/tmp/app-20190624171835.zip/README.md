<img src="./assets/logo.png" align="right" title="CTI Integration logo" alt="App Logo" width="70px" height="70px">

# CTI Integration

The CTI integration app is a Zendesk Support top bar app. It is intended to simulate an integration between Zendesk Support and a CTI partner through Talk Partner Edition APIs. The app let's the user demo a call coming in, the dynamic creation of a call ticket, and dynamic update of the ticket with the call information & recording.

<img src="https://cl.ly/44295a3b4426/Screen%252520Recording%2525202019-06-24%252520at%25252012.37%252520pm.gif" width="600px">
<img src="https://cl.ly/c12819af79d6/Screen%252520Recording%2525202019-06-24%252520at%25252012.35%252520pm.gif" width="200px">

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

### Screenshot(s):
[put your screenshots down here.]
